"""FotoSearch local backend."""
